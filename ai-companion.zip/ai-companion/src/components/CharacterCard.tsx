import Link from "next/link";
import type { Character } from "@/lib/types";

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export default function CharacterCard({ character }: { character: Character }) {
  return (
    <Link
      href={`/chat/${character.id}`}
      className="card-hover animate-fade-in group flex flex-col overflow-hidden rounded-xl2 border border-border bg-surface"
    >
      <div className="flex h-44 items-center justify-center bg-brand-gradient/20 bg-gradient-to-br from-primary/30 to-primary2/30">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-brand-gradient text-2xl font-bold text-white shadow-lg">
          {initials(character.name)}
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">{character.name}</h3>
          <span className="text-xs text-muted">{character.age} yaş</span>
        </div>
        <p className="line-clamp-2 text-sm text-muted">{character.description}</p>
        <div className="mt-1 flex flex-wrap gap-1.5">
          {character.personality
            .split(/[,،]/)
            .slice(0, 3)
            .map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-border bg-surface2 px-2.5 py-0.5 text-xs text-muted"
              >
                {tag.trim()}
              </span>
            ))}
        </div>
        <div className="mt-3">
          <span className="inline-flex w-full items-center justify-center rounded-full bg-brand-gradient py-2 text-sm font-medium text-white transition group-hover:opacity-90">
            Chat
          </span>
        </div>
      </div>
    </Link>
  );
}
