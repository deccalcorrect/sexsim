import { NextResponse } from "next/server";
import { v4 as uuid } from "uuid";
import { getSessionUser } from "@/lib/auth";
import { getCharacterById } from "@/lib/characters/repo";
import { generateCharacterImage } from "@/lib/image/provider";
import { getDb } from "@/lib/db";

export async function POST(req: Request) {
  const user = getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Fotoğraf istemek için giriş yapmalısın." }, { status: 401 });
  }

  try {
    const { characterId, scenePrompt } = await req.json();
    const character = getCharacterById(characterId);
    if (!character) {
      return NextResponse.json({ error: "Karakter bulunamadı." }, { status: 404 });
    }

    const result = await generateCharacterImage(character, scenePrompt || "casual everyday photo");
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 502 });
    }

    const db = getDb();
    const id = uuid();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO messages (id, user_id, character_id, role, content, image_url, created_at) VALUES (?, ?, ?, 'assistant', ?, ?, ?)`
    ).run(id, user.id, character.id, "İşte bir fotoğrafım! 📸", result.url, now);

    return NextResponse.json({
      message: { id, role: "assistant", content: "İşte bir fotoğrafım! 📸", image_url: result.url, created_at: now },
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Fotoğraf şu anda oluşturulamadı." }, { status: 500 });
  }
}
