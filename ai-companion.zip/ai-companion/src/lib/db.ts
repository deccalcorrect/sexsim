import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

// Basit, sıfır-konfigürasyonlu SQLite veritabanı.
// İstenirse ileride Supabase/Postgres'e geçmek için bu dosyadaki
// fonksiyon imzalarını koruyup içini değiştirmek yeterli olur.

const DB_PATH = process.env.DATABASE_PATH || "./data/app.db";

function ensureDir() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

declare global {
  // eslint-disable-next-line no-var
  var __aiCompanionDb: Database.Database | undefined;
}

function createConnection() {
  ensureDir();
  const db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");
  migrate(db);
  return db;
}

function migrate(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS characters (
      id TEXT PRIMARY KEY,
      owner_id TEXT, -- null = sistem karakteri (seed)
      name TEXT NOT NULL,
      age INTEGER,
      gender TEXT,
      avatar TEXT,
      description TEXT,
      personality TEXT,
      background TEXT,
      speaking_style TEXT,
      interests TEXT,       -- JSON array string
      dislikes TEXT,        -- JSON array string
      relationship_type TEXT,
      greeting TEXT,
      system_prompt TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      character_id TEXT NOT NULL,
      role TEXT NOT NULL, -- 'user' | 'assistant'
      content TEXT NOT NULL,
      image_url TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS memories (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      character_id TEXT NOT NULL,
      memory TEXT NOT NULL,
      importance INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS relationships (
      user_id TEXT NOT NULL,
      character_id TEXT NOT NULL,
      level INTEGER NOT NULL DEFAULT 5,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (user_id, character_id)
    );

    CREATE INDEX IF NOT EXISTS idx_messages_lookup
      ON messages(user_id, character_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_memories_lookup
      ON memories(user_id, character_id);
  `);
}

export function getDb() {
  if (!global.__aiCompanionDb) {
    global.__aiCompanionDb = createConnection();
  }
  return global.__aiCompanionDb;
}
