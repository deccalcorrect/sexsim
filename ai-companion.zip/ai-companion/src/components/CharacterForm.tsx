"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const initialState = {
  name: "",
  age: 22,
  gender: "Belirtilmemiş",
  description: "",
  personality: "",
  speaking_style: "",
  interests: "",
  dislikes: "",
  background: "",
  greeting: "",
  relationship_type: "Arkadaş",
};

export default function CharacterForm() {
  const [form, setForm] = useState(initialState);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  function update<K extends keyof typeof initialState>(key: K, value: (typeof initialState)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!form.name || !form.description || !form.personality) {
      setError("İsim, görünüş ve kişilik alanları zorunludur.");
      return;
    }

    setLoading(true);
    const res = await fetch("/api/characters", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(data.error || "Karakter oluşturulamadı.");
      return;
    }

    router.push(`/chat/${data.character.id}`);
  }

  const fields: { key: keyof typeof initialState; label: string; type?: string; area?: boolean }[] = [
    { key: "name", label: "Name *" },
    { key: "age", label: "Age", type: "number" },
    { key: "gender", label: "Gender" },
    { key: "description", label: "Appearance *", area: true },
    { key: "personality", label: "Personality *", area: true },
    { key: "speaking_style", label: "Speaking style" },
    { key: "interests", label: "Interests (virgülle ayır)" },
    { key: "dislikes", label: "Dislikes (virgülle ayır)" },
    { key: "background", label: "Background", area: true },
    { key: "relationship_type", label: "Relationship type" },
    { key: "greeting", label: "Greeting", area: true },
  ];

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-2xl space-y-4">
      {fields.map((f) => (
        <div key={f.key}>
          <label className="mb-1 block text-sm text-muted">{f.label}</label>
          {f.area ? (
            <textarea
              value={form[f.key] as string}
              onChange={(e) => update(f.key, e.target.value as any)}
              rows={3}
              className="w-full rounded-lg border border-border bg-surface2 px-4 py-2.5 text-sm outline-none focus:border-primary"
            />
          ) : (
            <input
              type={f.type || "text"}
              value={form[f.key] as string | number}
              onChange={(e) =>
                update(f.key, (f.type === "number" ? Number(e.target.value) : e.target.value) as any)
              }
              className="w-full rounded-lg border border-border bg-surface2 px-4 py-2.5 text-sm outline-none focus:border-primary"
            />
          )}
        </div>
      ))}

      {error && <p className="text-sm text-primary2">{error}</p>}

      <button
        disabled={loading}
        className="w-full rounded-full bg-brand-gradient py-3 font-medium text-white transition hover:opacity-90 disabled:opacity-50"
      >
        {loading ? "Oluşturuluyor..." : "Generate Character"}
      </button>
    </form>
  );
}
