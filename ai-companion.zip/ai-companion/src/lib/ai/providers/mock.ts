import type { AiChatContext, AiProvider } from "../provider";

/**
 * Hiçbir API key gerektirmeyen, tamamen ücretsiz çalışan varsayılan sağlayıcı.
 * Gerçek bir LLM değildir; karakterin kişiliğine, konuşma tarzına ve
 * kullanıcının mesajındaki anahtar kelimelere göre şablon tabanlı,
 * makul ölçüde tutarlı cevaplar üretir. Böylece proje sıfır maliyetle
 * uçtan uca çalışır; gerçek bir LLM istenirse AI_PROVIDER=openrouter
 * veya AI_PROVIDER=ollama ile değiştirilebilir.
 */
export class MockProvider implements AiProvider {
  name = "mock";

  async generateReply(ctx: AiChatContext): Promise<string> {
    const { character, userMessage, relationshipTier, relevantMemories } = ctx;
    const msg = userMessage.toLowerCase();

    const emojiPool = character.speaking_style?.toLowerCase().includes("resmi")
      ? []
      : ["😊", "🙂", "😄", "✨", "😉"];
    const emoji = emojiPool.length ? emojiPool[Math.floor(Math.random() * emojiPool.length)] : "";

    // Basit niyet tespiti
    if (/\b(selam|merhaba|hey|hi|hello)\b/.test(msg)) {
      return `Selam! Seni gördüğüme sevindim ${emoji} Bugün nasıl geçiyor?`;
    }

    if (/foto|resim|fotoğraf|selfie/.test(msg)) {
      return `Hemen bir tane paylaşayım, bir saniye... ${emoji}`;
    }

    if (/nasılsın|naber|ne haber/.test(msg)) {
      const moodByTier: Record<string, string> = {
        Stranger: "İyiyim, teşekkür ederim. Sen nasılsın?",
        Acquaintance: "Oldukça iyiyim, seninle konuşmak güzel.",
        Friend: "Gayet iyiyim, seninle sohbet etmeyi seviyorum!",
        "Close Friend": "Harikayım, özellikle seninle konuşunca daha da iyi oluyorum.",
        "Best Friend": "Süperim! Seni düşünüyordum aslında 🙂",
      };
      return moodByTier[relationshipTier] || "İyiyim, sen nasılsın?";
    }

    if (character.interests?.some((i) => msg.includes(i.toLowerCase()))) {
      const matched = character.interests.find((i) => msg.includes(i.toLowerCase()));
      return `${matched} konusuna girince ben de heyecanlanıyorum ${emoji} Bu konuda neler düşünüyorsun?`;
    }

    if (relevantMemories.length > 0 && Math.random() < 0.35) {
      const mem = relevantMemories[0];
      return `Bunu duymak güzel. Bu arada hatırlıyorum, sen bana "${mem}" demiştin — hâlâ öyle mi?`;
    }

    // Kişiliğe göre genel cevap havuzu
    const personalityReplies = [
      `Anlıyorum, biraz daha anlatır mısın?`,
      `Bu konuda ne hissettiğini merak ediyorum.`,
      `Hmm, ilginç bir bakış açısı ${emoji}`,
      `Devam et, seni dinliyorum.`,
      `Bunu duyunca gülümsedim ${emoji}`,
    ];

    return personalityReplies[Math.floor(Math.random() * personalityReplies.length)];
  }
}
