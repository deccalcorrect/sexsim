import type { Character } from "../types";

export interface ImageProvider {
  name: string;
  /** dataUrl (base64) veya http(s) URL döner */
  generateImage(character: Character, scenePrompt: string): Promise<string>;
}

/**
 * TEK DEĞİŞİM NOKTASI — görsel sağlayıcısını değiştirmek için
 * IMAGE_PROVIDER env değişkenini değiştir: "placeholder" | "huggingface"
 * Yeni bir görsel API'si eklemek için providers/ klasörüne dosya
 * ekleyip aşağıdaki switch'e bir case eklemen yeterli.
 */
export async function getImageProvider(): Promise<ImageProvider> {
  const providerName = (process.env.IMAGE_PROVIDER || "placeholder").toLowerCase();

  switch (providerName) {
    case "huggingface": {
      const { HuggingFaceProvider } = await import("./providers/huggingface");
      return new HuggingFaceProvider();
    }
    case "placeholder":
    default: {
      const { PlaceholderProvider } = await import("./providers/placeholder");
      return new PlaceholderProvider();
    }
  }
}

/**
 * Karakterin görünüşünü koruyarak tutarlı bir görsel prompt'u
 * oluşturur. Karakterin yüz/görünüş tanımı (description alanı)
 * her seferinde prompt'un başına eklenir; böylece farklı sahnelerde
 * bile karakter mümkün olduğunca tutarlı kalır.
 */
export function buildCharacterImagePrompt(character: Character, scenePrompt: string) {
  return [
    `portrait of ${character.name}, ${character.age} year old`,
    character.description,
    scenePrompt,
    "consistent face, high quality, soft lighting, safe for work",
  ]
    .filter(Boolean)
    .join(", ");
}

export async function generateCharacterImage(character: Character, scenePrompt: string) {
  const provider = await getImageProvider();
  const fullPrompt = buildCharacterImagePrompt(character, scenePrompt);
  try {
    const url = await provider.generateImage(character, fullPrompt);
    return { ok: true as const, url };
  } catch (err) {
    console.error("[image] generation failed:", err);
    return { ok: false as const, error: "Fotoğraf şu anda oluşturulamadı." };
  }
}
