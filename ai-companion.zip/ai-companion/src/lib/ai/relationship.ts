import { getDb } from "../db";

const TIERS: { min: number; max: number; name: string }[] = [
  { min: 0, max: 20, name: "Stranger" },
  { min: 21, max: 40, name: "Acquaintance" },
  { min: 41, max: 60, name: "Friend" },
  { min: 61, max: 80, name: "Close Friend" },
  { min: 81, max: 100, name: "Best Friend" },
];

export function tierForLevel(level: number): string {
  const clamped = Math.max(0, Math.min(100, level));
  return TIERS.find((t) => clamped >= t.min && clamped <= t.max)?.name || "Stranger";
}

const POSITIVE_WORDS = ["teşekkür", "seviyorum", "harika", "güzel", "iyi", "mutlu", "süper", "❤", "😊", "😍"];
const NEGATIVE_WORDS = ["kızgın", "sinir", "kötü", "üzgün", "nefret", "sıkıldım"];

export function getRelationship(userId: string, characterId: string) {
  const db = getDb();
  const row = db
    .prepare(`SELECT * FROM relationships WHERE user_id = ? AND character_id = ?`)
    .get(userId, characterId) as { level: number } | undefined;

  if (!row) {
    const level = 5; // yeni tanışmalar "Stranger" tier'ında başlar
    db.prepare(
      `INSERT INTO relationships (user_id, character_id, level, updated_at) VALUES (?, ?, ?, ?)`
    ).run(userId, characterId, level, new Date().toISOString());
    return { level, tier: tierForLevel(level) };
  }
  return { level: row.level, tier: tierForLevel(row.level) };
}

/**
 * Her mesaj alışverişinden sonra ilişki seviyesini küçük miktarlarda
 * günceller. Basit ve öngörülebilir tutulur: mesaj başına +1,
 * olumlu kelimeler +1 ekstra, olumsuz kelimeler -1.
 */
export function updateRelationshipAfterMessage(userId: string, characterId: string, userMessage: string) {
  const db = getDb();
  const current = getRelationship(userId, characterId);
  const msg = userMessage.toLowerCase();

  let delta = 1; // her etkileşim doğal olarak biraz yakınlaştırır
  if (POSITIVE_WORDS.some((w) => msg.includes(w))) delta += 1;
  if (NEGATIVE_WORDS.some((w) => msg.includes(w))) delta -= 2;

  const newLevel = Math.max(0, Math.min(100, current.level + delta));

  db.prepare(
    `UPDATE relationships SET level = ?, updated_at = ? WHERE user_id = ? AND character_id = ?`
  ).run(newLevel, new Date().toISOString(), userId, characterId);

  return { level: newLevel, tier: tierForLevel(newLevel) };
}
