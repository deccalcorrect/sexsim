# Companion — AI Character Chat (MVP)

Candy.ai benzeri, kullanıcıların AI karakterler oluşturup onlarla sohbet
edebildiği, karakterlerin kişiliği/hafızası/ilişki seviyesi olan bir web
uygulaması. **Sıfır maliyetle, hiçbir API key olmadan** çalışacak şekilde
tasarlandı; istenirse gerçek LLM/görsel sağlayıcılarıyla genişletilebilir.

## Hızlı Başlangıç

```bash
npm install
cp .env.example .env      # varsayılan ayarlar (mock AI + placeholder görsel) zaten ücretsiz çalışır
npm run dev                # http://localhost:3000
```

Veritabanı (`data/app.db`) ve 3 örnek karakter (Maya, Alex, Luna) ilk
istekte otomatik oluşturulur — ayrıca elle çalıştırmak istersen:

```bash
npm run seed
```

Üretim derlemesi:

```bash
npm run build
npm run start
```

## Mimari

```
src/
  app/                    # Next.js App Router sayfaları + API route'ları
    page.tsx              # Ana sayfa / Discover
    chat/[id]/page.tsx     # Sohbet ekranı
    create-character/      # Karakter oluşturucu
    login/, register/      # Auth sayfaları
    my-chats/               # Sohbet geçmişi listesi
    api/                   # auth, characters, chat, image, my-chats route'ları
  components/              # Navbar, CharacterCard, ChatWindow, MessageBubble, ...
  lib/
    db.ts                  # SQLite (better-sqlite3), sıfır-konfigürasyon
    auth.ts                # JWT + bcrypt tabanlı basit auth
    types.ts
    ai/
      provider.ts          # ⭐ LLM SAĞLAYICI SOYUTLAMASI (tek değişim noktası)
      providers/           # mock (ücretsiz), openrouter, ollama, claude
      systemPrompt.ts       # Karakter verisinden otomatik system prompt üretimi
      memory.ts             # Kural tabanlı hafıza çıkarımı + retrieval
      relationship.ts        # İlişki seviyesi (Stranger → Best Friend)
    image/
      provider.ts           # ⭐ GÖRSEL SAĞLAYICI SOYUTLAMASI (tek değişim noktası)
      providers/            # placeholder (ücretsiz SVG), huggingface
    characters/
      seed.ts, repo.ts       # Örnek karakterler + karakter CRUD
```

## Sağlayıcı Değiştirme (tek yerden)

### LLM (AI cevapları)

`.env` dosyasında `AI_PROVIDER` değerini değiştir:

| Değer | Açıklama | Key gerekir mi? |
|---|---|---|
| `mock` (varsayılan) | Kural/şablon tabanlı, tamamen ücretsiz | Hayır |
| `openrouter` | [openrouter.ai](https://openrouter.ai) üzerinden `:free` etiketli modeller (ör. Llama 3.1 8B) | Evet (ücretsiz kotalı) |
| `ollama` | Yerelde çalışan açık kaynak modeller ([ollama.com](https://ollama.com)) | Hayır (yerel) |
| `claude` | Anthropic API (opsiyonel, ücretli) | Evet |

Yeni bir sağlayıcı eklemek için `lib/ai/providers/` içine `AiProvider`
arayüzünü uygulayan bir dosya ekleyip `lib/ai/provider.ts` içindeki
switch'e bir `case` eklemen yeterli.

### Görsel Üretimi

`.env` dosyasında `IMAGE_PROVIDER` değerini değiştir:

| Değer | Açıklama | Key gerekir mi? |
|---|---|---|
| `placeholder` (varsayılan) | Karaktere özel renkli SVG avatar üretir | Hayır |
| `huggingface` | Hugging Face Inference API (Stable Diffusion vb.) | Evet (ücretsiz kotalı) |

`generateCharacterImage(character, scenePrompt)` fonksiyonu her zaman
`{ ok, url }` veya `{ ok: false, error }` döner; görsel üretimi başarısız
olursa sohbet **çökmez**, kullanıcıya "Fotoğraf şu anda oluşturulamadı."
mesajı gösterilir. Karakterin görünüş tanımı (`description`) her prompt'un
başına otomatik eklenir; bu, farklı sahnelerde karakterin mümkün
olduğunca tutarlı kalmasını sağlar (tam piksel-birebir tutarlılık için
gerçek bir "karakter kilitleme" — LoRA / referans görsel / IP-Adapter —
modeli entegre edilmesi gerekir; bu MVP'de yok).

## Hafıza Sistemi

Her mesaj sonsuza kadar prompt'a eklenmez:

1. `extractAndStoreMemories()` — mesajı kural tabanlı regex'lerle tarar
   (yaşadığı yer, sevdiği/sevmediği şeyler, mesleği vb.) ve `memories`
   tablosuna kaydeder — **LLM çağrısı gerektirmez**.
2. `retrieveRelevantMemories()` — yeni mesajla kelime örtüşmesine göre
   en alakalı birkaç hafızayı getirir ve sadece bunlar system prompt'a
   eklenir.
3. Gerçek bir LLM sağlayıcısı kullanılıyorsa (openrouter/claude), bu
   fonksiyon istenirse LLM tabanlı, daha akıllı bir çıkarıma da
   genişletilebilir — arayüz aynı kalır.

## İlişki Sistemi

`relationships` tablosunda `user_id + character_id` başına 0-100 arası
bir `level` tutulur. Her mesajda küçük miktarlarda değişir (temel +1,
olumlu kelimeler +1 ekstra, olumsuz kelimeler -2). Kademeler:

```
0-20   Stranger
21-40  Acquaintance
41-60  Friend
61-80  Close Friend
81-100 Best Friend
```

## Bilinen Sınırlamalar / Sonraki Adımlar

- Veritabanı SQLite dosyası — tek sunuculuk MVP için yeterli;
  çoklu-instance / production ölçek için Supabase/Postgres'e geçmek
  istersen `lib/db.ts` içindeki fonksiyon imzalarını koruyup içini
  değiştirmen yeterli (repo katmanı zaten bu soyutlamayı kullanıyor).
- Auth basit ve kendi yazdığımız JWT+cookie sistemi; production'da
  Supabase Auth / NextAuth gibi daha olgun bir çözüme geçilebilir.
- Görsel üretiminde karakter tutarlılığı temel seviyede (prompt'a
  görünüş açıklaması ekleme); gerçek yüz tutarlılığı için referans
  görsel / IP-Adapter destekli bir sağlayıcı eklenmesi gerekir.
- Mock AI sağlayıcısı gerçek bir dil modeli değildir, şablon tabanlıdır;
  daha doğal cevaplar için `AI_PROVIDER=openrouter` (ücretsiz modeller)
  önerilir.
- İçerik güvenliği: sistem promptu ve görsel promptu cinsel/zararlı
  içerik üretmemesi yönünde talimat içerir; canlıya almadan önce kendi
  moderasyon/güvenlik katmanını eklemen önerilir.

## Ortam Değişkenleri

Bkz. `.env.example`. Varsayılan ayarlarla (`AI_PROVIDER=mock`,
`IMAGE_PROVIDER=placeholder`) proje **hiçbir key olmadan** uçtan uca
çalışır.
