import type { AiChatContext, AiProvider } from "../provider";

/**
 * OpenRouter (https://openrouter.ai) — birçok modelin ücretsiz ("
 * :free" son ekli) sürümlerine erişim sağlar. API key gerektirir
 * ama ücretsiz kotalı modeller kullanılabilir.
 */
export class OpenRouterProvider implements AiProvider {
  name = "openrouter";

  async generateReply(ctx: AiChatContext): Promise<string> {
    const apiKey = process.env.OPENROUTER_API_KEY;
    const model = process.env.OPENROUTER_MODEL || "meta-llama/llama-3.1-8b-instruct:free";
    if (!apiKey) {
      throw new Error("OPENROUTER_API_KEY tanımlı değil. .env dosyanı kontrol et.");
    }

    const messages = buildMessages(ctx);

    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ model, messages, max_tokens: 400 }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`OpenRouter hatası (${res.status}): ${text}`);
    }

    const data = await res.json();
    return data.choices?.[0]?.message?.content?.trim() || "...";
  }
}

export function buildMessages(ctx: AiChatContext) {
  const memoryBlock = ctx.relevantMemories.length
    ? `\n\nKullanıcı hakkında bilinenler:\n- ${ctx.relevantMemories.join("\n- ")}`
    : "";

  const systemContent =
    `${ctx.character.system_prompt}${memoryBlock}\n\nMevcut ilişki seviyesi: ${ctx.relationshipTier}.`;

  return [
    { role: "system", content: systemContent },
    ...ctx.history.slice(-12),
    { role: "user", content: ctx.userMessage },
  ];
}
