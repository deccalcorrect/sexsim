import { NextResponse } from "next/server";
import { v4 as uuid } from "uuid";
import { getDb } from "@/lib/db";
import { hashPassword, signSession, setSessionCookie, findUserByEmail } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { email, password, displayName } = await req.json();

    if (!email || !password || password.length < 6) {
      return NextResponse.json(
        { error: "Geçerli bir e-posta ve en az 6 karakterli bir şifre girin." },
        { status: 400 }
      );
    }

    if (findUserByEmail(email)) {
      return NextResponse.json({ error: "Bu e-posta zaten kayıtlı." }, { status: 409 });
    }

    const db = getDb();
    const id = uuid();
    const password_hash = await hashPassword(password);
    const display_name = displayName?.trim() || email.split("@")[0];

    db.prepare(
      `INSERT INTO users (id, email, password_hash, display_name, created_at) VALUES (?, ?, ?, ?, ?)`
    ).run(id, email, password_hash, display_name, new Date().toISOString());

    const token = signSession({ id, email, display_name });
    setSessionCookie(token);

    return NextResponse.json({ id, email, display_name });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Kayıt sırasında bir hata oluştu." }, { status: 500 });
  }
}
