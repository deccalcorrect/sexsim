import { NextResponse } from "next/server";
import { findUserByEmail, verifyPassword, signSession, setSessionCookie } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();
    const user = findUserByEmail(email);

    if (!user || !(await verifyPassword(password, user.password_hash))) {
      return NextResponse.json({ error: "E-posta veya şifre hatalı." }, { status: 401 });
    }

    const token = signSession({ id: user.id, email: user.email, display_name: user.display_name });
    setSessionCookie(token);

    return NextResponse.json({ id: user.id, email: user.email, display_name: user.display_name });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Giriş sırasında bir hata oluştu." }, { status: 500 });
  }
}
