import { NextResponse } from "next/server";
import { getAllCharacters, createCharacter } from "@/lib/characters/repo";
import { getSessionUser } from "@/lib/auth";

export async function GET() {
  const characters = getAllCharacters();
  return NextResponse.json({ characters });
}

export async function POST(req: Request) {
  const user = getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Karakter oluşturmak için giriş yapmalısın." }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, age, gender, description, personality, background, speaking_style, relationship_type } = body;

    if (!name || !description || !personality) {
      return NextResponse.json(
        { error: "İsim, görünüş ve kişilik alanları zorunludur." },
        { status: 400 }
      );
    }

    const interests: string[] = Array.isArray(body.interests)
      ? body.interests
      : String(body.interests || "")
          .split(",")
          .map((s: string) => s.trim())
          .filter(Boolean);

    const dislikes: string[] = Array.isArray(body.dislikes)
      ? body.dislikes
      : String(body.dislikes || "")
          .split(",")
          .map((s: string) => s.trim())
          .filter(Boolean);

    const character = createCharacter({
      ownerId: user.id,
      name,
      age: Number(age) || 21,
      gender: gender || "Belirtilmemiş",
      description,
      personality,
      background: background || "",
      speaking_style: speaking_style || "doğal ve samimi",
      interests,
      dislikes,
      relationship_type: relationship_type || "Arkadaş",
      greeting: body.greeting,
    });

    return NextResponse.json({ character });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Karakter oluşturulurken bir hata oluştu." }, { status: 500 });
  }
}
