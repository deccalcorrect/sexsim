import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0b10",
        surface: "#15151d",
        surface2: "#1c1c27",
        border: "#2a2a38",
        primary: "#a855f7",
        primary2: "#ec4899",
        text: "#f4f4f7",
        muted: "#9797a8",
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg, #a855f7 0%, #ec4899 100%)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};
export default config;
