import { getDb } from "../src/lib/db";
import { SEED_CHARACTERS, buildSeedCharacterRow } from "../src/lib/characters/seed";

const db = getDb();

const insert = db.prepare(`
  INSERT OR IGNORE INTO characters
  (id, owner_id, name, age, gender, avatar, description, personality, background,
   speaking_style, interests, dislikes, relationship_type, greeting, system_prompt, created_at)
  VALUES (@id, @owner_id, @name, @age, @gender, @avatar, @description, @personality, @background,
   @speaking_style, @interests, @dislikes, @relationship_type, @greeting, @system_prompt, @created_at)
`);

for (const seed of SEED_CHARACTERS) {
  const row = buildSeedCharacterRow(seed);
  insert.run({
    ...row,
    interests: JSON.stringify(row.interests),
    dislikes: JSON.stringify(row.dislikes),
  });
  console.log(`Seeded: ${row.name}`);
}

console.log("Seed tamamlandı.");
