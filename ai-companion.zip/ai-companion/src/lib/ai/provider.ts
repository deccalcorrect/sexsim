import type { Character } from "../types";

export interface AiChatContext {
  character: Character;
  relevantMemories: string[];
  history: { role: "user" | "assistant"; content: string }[];
  relationshipTier: string;
  userMessage: string;
}

export interface AiProvider {
  name: string;
  generateReply(ctx: AiChatContext): Promise<string>;
}

/**
 * TEK DEĞİŞİM NOKTASI
 * ---------------------------------------------------------
 * Sağlayıcı değiştirmek için sadece AI_PROVIDER env değişkenini
 * değiştir: "mock" | "openrouter" | "ollama" | "claude"
 * Yeni bir sağlayıcı eklemek için providers/ klasörüne bir dosya
 * ekleyip aşağıdaki switch'e bir case eklemen yeterli.
 */
export async function getAiProvider(): Promise<AiProvider> {
  const providerName = (process.env.AI_PROVIDER || "mock").toLowerCase();

  switch (providerName) {
    case "openrouter": {
      const { OpenRouterProvider } = await import("./providers/openrouter");
      return new OpenRouterProvider();
    }
    case "ollama": {
      const { OllamaProvider } = await import("./providers/ollama");
      return new OllamaProvider();
    }
    case "claude": {
      const { ClaudeProvider } = await import("./providers/claude");
      return new ClaudeProvider();
    }
    case "mock":
    default: {
      const { MockProvider } = await import("./providers/mock");
      return new MockProvider();
    }
  }
}
