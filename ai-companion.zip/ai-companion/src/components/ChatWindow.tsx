"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import type { Character, ChatMessage } from "@/lib/types";
import MessageBubble from "./MessageBubble";
import RelationshipBadge from "./RelationshipBadge";

interface Props {
  character: Character;
  initialHistory: ChatMessage[];
  initialRelationship: { level: number; tier: string };
  isLoggedIn: boolean;
}

export default function ChatWindow({ character, initialHistory, initialRelationship, isLoggedIn }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialHistory);
  const [relationship, setRelationship] = useState(initialRelationship);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [requestingPhoto, setRequestingPhoto] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  async function sendMessage(text: string) {
    if (!text.trim() || sending) return;
    setInput("");

    const optimisticUserMsg: ChatMessage = {
      id: `tmp-${Date.now()}`,
      user_id: "me",
      character_id: character.id,
      role: "user",
      content: text.trim(),
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimisticUserMsg]);
    setSending(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ characterId: character.id, message: text.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            user_id: "me",
            character_id: character.id,
            role: "assistant",
            content: data.error || "Bir hata oluştu.",
            created_at: new Date().toISOString(),
          },
        ]);
        return;
      }
      setMessages((prev) => [...prev, data.message]);
      setRelationship(data.relationship);
    } finally {
      setSending(false);
    }
  }

  async function requestPhoto() {
    if (requestingPhoto) return;
    setRequestingPhoto(true);
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ characterId: character.id }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessages((prev) => [...prev, data.message]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            user_id: "me",
            character_id: character.id,
            role: "assistant",
            content: data.error || "Fotoğraf şu anda oluşturulamadı.",
            created_at: new Date().toISOString(),
          },
        ]);
      }
    } finally {
      setRequestingPhoto(false);
    }
  }

  return (
    <div className="flex h-[calc(100vh-160px)] flex-col overflow-hidden rounded-xl2 border border-border bg-surface md:flex-row">
      {/* Sol panel - karakter bilgisi */}
      <aside className="flex flex-col items-center gap-3 border-b border-border p-5 md:w-64 md:border-b-0 md:border-r">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-brand-gradient text-2xl font-bold text-white">
          {character.name[0]}
        </div>
        <h2 className="text-lg font-semibold">{character.name}</h2>
        <div className="flex items-center gap-1.5 text-xs text-emerald-400">
          <span className="h-2 w-2 rounded-full bg-emerald-400" /> Online (AI)
        </div>
        <RelationshipBadge tier={relationship.tier} level={relationship.level} />
        <div className="mt-2 flex flex-wrap justify-center gap-1.5">
          {character.personality
            .split(/[,،]/)
            .slice(0, 4)
            .map((t) => (
              <span key={t} className="rounded-full border border-border bg-surface2 px-2 py-0.5 text-[11px] text-muted">
                {t.trim()}
              </span>
            ))}
        </div>
        <p className="mt-2 text-center text-xs text-muted">{character.description}</p>
      </aside>

      {/* Orta - mesajlar */}
      <div className="flex flex-1 flex-col">
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {messages.length === 0 && (
            <MessageBubble role="assistant" content={character.greeting} />
          )}
          {messages.map((m) => (
            <MessageBubble key={m.id} role={m.role} content={m.content} imageUrl={m.image_url} timestamp={m.created_at} />
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="flex items-center gap-1 rounded-2xl border border-border bg-surface px-4 py-3">
                <span className="typing-dot h-1.5 w-1.5 rounded-full bg-muted [animation-delay:0s]" />
                <span className="typing-dot h-1.5 w-1.5 rounded-full bg-muted [animation-delay:0.2s]" />
                <span className="typing-dot h-1.5 w-1.5 rounded-full bg-muted [animation-delay:0.4s]" />
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Alt - input */}
        {isLoggedIn ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(input);
            }}
            className="flex items-center gap-2 border-t border-border p-3"
          >
            <button
              type="button"
              onClick={requestPhoto}
              disabled={requestingPhoto}
              title="Fotoğraf iste"
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-border text-muted transition hover:border-primary hover:text-text disabled:opacity-50"
            >
              📷
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`${character.name}'e bir mesaj yaz...`}
              className="flex-1 rounded-full border border-border bg-surface2 px-4 py-2.5 text-sm outline-none focus:border-primary"
            />
            <button
              type="submit"
              disabled={sending || !input.trim()}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-gradient text-white transition hover:opacity-90 disabled:opacity-50"
            >
              ➤
            </button>
          </form>
        ) : (
          <div className="flex items-center justify-center gap-2 border-t border-border p-4 text-sm text-muted">
            Sohbet etmek için{" "}
            <Link href="/login" className="text-primary">
              giriş yap
            </Link>
            .
          </div>
        )}
      </div>
    </div>
  );
}
