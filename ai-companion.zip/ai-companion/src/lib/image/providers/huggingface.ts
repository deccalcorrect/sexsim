import type { ImageProvider } from "../provider";
import type { Character } from "../../types";

/**
 * Hugging Face Inference API — ücretsiz kotalı text-to-image modelleri
 * kullanır (ör. Stable Diffusion). API key gerektirir ama ücretsiz
 * hesapla sınırlı sayıda istek yapılabilir.
 * https://huggingface.co/settings/tokens
 */
export class HuggingFaceProvider implements ImageProvider {
  name = "huggingface";

  async generateImage(_character: Character, fullPrompt: string): Promise<string> {
    const apiKey = process.env.HUGGINGFACE_API_KEY;
    const model = process.env.HUGGINGFACE_MODEL || "stabilityai/stable-diffusion-xl-base-1.0";
    if (!apiKey) {
      throw new Error("HUGGINGFACE_API_KEY tanımlı değil. .env dosyanı kontrol et.");
    }

    const res = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ inputs: fullPrompt }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Hugging Face hatası (${res.status}): ${text}`);
    }

    const arrayBuffer = await res.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString("base64");
    return `data:image/jpeg;base64,${base64}`;
  }
}
