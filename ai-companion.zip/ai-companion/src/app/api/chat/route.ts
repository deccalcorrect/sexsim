import { NextResponse } from "next/server";
import { v4 as uuid } from "uuid";
import { getDb } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { getCharacterById } from "@/lib/characters/repo";
import { getAiProvider } from "@/lib/ai/provider";
import { extractAndStoreMemories, retrieveRelevantMemories } from "@/lib/ai/memory";
import { updateRelationshipAfterMessage } from "@/lib/ai/relationship";
import { generateCharacterImage } from "@/lib/image/provider";
import type { ChatMessage } from "@/lib/types";

const PHOTO_REQUEST_REGEX = /(foto|resim|fotoğraf|selfie|ne giyiyorsun|görüntü)/i;

export async function POST(req: Request) {
  const user = getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Sohbet etmek için giriş yapmalısın." }, { status: 401 });
  }

  try {
    const { characterId, message } = await req.json();
    if (!characterId || !message?.trim()) {
      return NextResponse.json({ error: "Mesaj boş olamaz." }, { status: 400 });
    }

    const character = getCharacterById(characterId);
    if (!character) {
      return NextResponse.json({ error: "Karakter bulunamadı." }, { status: 404 });
    }

    const db = getDb();
    const now = new Date().toISOString();

    // 1) Kullanıcı mesajını kaydet
    const userMsgId = uuid();
    db.prepare(
      `INSERT INTO messages (id, user_id, character_id, role, content, created_at) VALUES (?, ?, ?, 'user', ?, ?)`
    ).run(userMsgId, user.id, character.id, message.trim(), now);

    // 2) Hafızayı güncelle (basit kural tabanlı çıkarım, LLM gerektirmez)
    extractAndStoreMemories(user.id, character.id, message.trim());
    const relevantMemories = retrieveRelevantMemories(user.id, character.id, message.trim());

    // 3) İlişki seviyesini güncelle
    const relationship = updateRelationshipAfterMessage(user.id, character.id, message.trim());

    // 4) Son mesajları al (prompt geçmişi için)
    const recentRows = db
      .prepare(
        `SELECT role, content FROM messages WHERE user_id = ? AND character_id = ? ORDER BY created_at DESC LIMIT 20`
      )
      .all(user.id, character.id) as { role: "user" | "assistant"; content: string }[];
    const history = recentRows.reverse();

    // 5) AI sağlayıcısından cevap al
    const provider = await getAiProvider();
    let replyText: string;
    try {
      replyText = await provider.generateReply({
        character,
        relevantMemories,
        history: history.slice(0, -1), // son mesaj (kullanıcının şu anki mesajı) hariç
        relationshipTier: relationship.tier,
        userMessage: message.trim(),
      });
    } catch (err) {
      console.error("[ai] provider error:", err);
      replyText =
        "Şu anda düşüncelerimi toparlayamadım, birazdan tekrar dener misin? (AI sağlayıcısında bir sorun oluştu)";
    }

    // 6) Fotoğraf isteği tespit edilirse görsel üret
    let imageUrl: string | null = null;
    if (PHOTO_REQUEST_REGEX.test(message)) {
      const result = await generateCharacterImage(character, "casual everyday photo, natural pose");
      if (result.ok) {
        imageUrl = result.url;
      } else {
        replyText += `\n\n(${result.error})`;
      }
    }

    // 7) Asistan mesajını kaydet
    const assistantMsgId = uuid();
    db.prepare(
      `INSERT INTO messages (id, user_id, character_id, role, content, image_url, created_at) VALUES (?, ?, ?, 'assistant', ?, ?, ?)`
    ).run(assistantMsgId, user.id, character.id, replyText, imageUrl, new Date().toISOString());

    const assistantMessage: ChatMessage = {
      id: assistantMsgId,
      user_id: user.id,
      character_id: character.id,
      role: "assistant",
      content: replyText,
      image_url: imageUrl,
      created_at: new Date().toISOString(),
    };

    return NextResponse.json({ message: assistantMessage, relationship });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Mesaj gönderilirken bir hata oluştu." }, { status: 500 });
  }
}
