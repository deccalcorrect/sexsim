"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

interface SessionUser {
  id: string;
  email: string;
  display_name: string;
}

export default function Navbar() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setUser(d.user))
      .finally(() => setLoading(false));
  }, [pathname]);

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.push("/");
    router.refresh();
  }

  const links = [
    { href: "/", label: "Discover" },
    { href: "/create-character", label: "Create Character" },
    { href: "/my-chats", label: "My Chats" },
  ];

  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-bg/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient text-sm font-bold">
            C
          </div>
          <span className="text-lg font-semibold tracking-tight">
            <span className="brand-text">Companion</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm text-muted md:flex">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`transition hover:text-text ${pathname === l.href ? "text-text" : ""}`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {loading ? null : user ? (
            <>
              <span className="hidden text-sm text-muted sm:inline">Merhaba, {user.display_name}</span>
              <button
                onClick={handleLogout}
                className="rounded-full border border-border px-4 py-1.5 text-sm text-muted transition hover:border-primary hover:text-text"
              >
                Çıkış
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="rounded-full border border-border px-4 py-1.5 text-sm text-muted transition hover:border-primary hover:text-text"
              >
                Login
              </Link>
              <Link
                href="/register"
                className="rounded-full bg-brand-gradient px-4 py-1.5 text-sm font-medium text-white transition hover:opacity-90"
              >
                Register
              </Link>
            </>
          )}
        </div>
      </div>

      {/* mobile nav */}
      <nav className="flex items-center gap-4 overflow-x-auto border-t border-border/60 px-4 py-2 text-sm text-muted md:hidden">
        {links.map((l) => (
          <Link key={l.href} href={l.href} className="whitespace-nowrap">
            {l.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
