import type { AiChatContext, AiProvider } from "../provider";
import { buildMessages } from "./openrouter";

/**
 * Yerel (local) çalışan açık kaynak modeller için — ör. Ollama
 * (https://ollama.com) makinende "ollama run llama3.1" ile çalışırken
 * kullanılır. Tamamen ücretsiz, internet gerektirmez, API key yok.
 */
export class OllamaProvider implements AiProvider {
  name = "ollama";

  async generateReply(ctx: AiChatContext): Promise<string> {
    const baseUrl = process.env.OLLAMA_BASE_URL || "http://localhost:11434";
    const model = process.env.OLLAMA_MODEL || "llama3.1";
    const messages = buildMessages(ctx);

    const res = await fetch(`${baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages, stream: false }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Ollama hatası (${res.status}): ${text}`);
    }

    const data = await res.json();
    return data.message?.content?.trim() || "...";
  }
}
