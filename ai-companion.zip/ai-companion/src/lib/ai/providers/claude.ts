import type { AiChatContext, AiProvider } from "../provider";

/**
 * Anthropic Claude API — opsiyonel, ücretli bir sağlayıcı.
 * Bu proje Claude'a bağımlı DEĞİLDİR; sadece bir seçenektir.
 * API key API route/server tarafında kalır, client'a asla gönderilmez.
 */
export class ClaudeProvider implements AiProvider {
  name = "claude";

  async generateReply(ctx: AiChatContext): Promise<string> {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error("ANTHROPIC_API_KEY tanımlı değil. .env dosyanı kontrol et.");
    }

    const memoryBlock = ctx.relevantMemories.length
      ? `\n\nKullanıcı hakkında bilinenler:\n- ${ctx.relevantMemories.join("\n- ")}`
      : "";
    const system = `${ctx.character.system_prompt}${memoryBlock}\n\nMevcut ilişki seviyesi: ${ctx.relationshipTier}.`;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 400,
        system,
        messages: [
          ...ctx.history.slice(-12).map((m) => ({ role: m.role, content: m.content })),
          { role: "user", content: ctx.userMessage },
        ],
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Claude API hatası (${res.status}): ${text}`);
    }

    const data = await res.json();
    const textBlock = data.content?.find((b: any) => b.type === "text");
    return textBlock?.text?.trim() || "...";
  }
}
