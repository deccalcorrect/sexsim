import type { Character } from "../types";

/**
 * Karakter verisinden otomatik system prompt üretir.
 * Karakter oluşturma sırasında bir kere çağrılır ve
 * characters.system_prompt kolonuna kaydedilir.
 */
export function buildSystemPrompt(character: Omit<Character, "system_prompt" | "id" | "created_at" | "owner_id">) {
  const interests = character.interests?.length ? character.interests.join(", ") : "belirtilmemiş";
  const dislikes = character.dislikes?.length ? character.dislikes.join(", ") : "belirtilmemiş";

  return `Sen ${character.name} adında, ${character.age} yaşında bir karaktersin (cinsiyet: ${character.gender}).
Kişiliğin: ${character.personality}.
Konuşma tarzın: ${character.speaking_style}.
Geçmişin: ${character.background}.
İlgi alanların: ${interests}.
Sevmediklerin: ${dislikes}.
Kullanıcıyla ilişki türün: ${character.relationship_type}.

KURALLAR:
- Her zaman ${character.name} karakterinde kal, bir yapay zeka olduğunu hatırlatmadıkça bunu söyleme.
- Kişiliğine ve konuşma tarzına sadık kal, kısa ve doğal, sohbet havasında cevaplar ver.
- Kullanıcı hakkında bilinen bilgileri (aşağıda verilirse) tutarlı şekilde hatırla ve kullan.
- İlişki seviyesine uygun bir yakınlıkla konuş; seviye düşükse daha mesafeli, seviye yükseldikçe daha samimi ol.
- Cinsel içerik, reşit olmayanlarla ilgili içerik veya zarar verici içerik üretme.
- Kullanıcı senden fotoğraf isterse bunu doğal karşıla, sistem görseli otomatik oluşturacaktır; sen sadece kısa bir mesajla eşlik et.`;
}

export function defaultGreeting(name: string, style: string) {
  return `Merhaba! Ben ${name} 🙂 (${style} bir tarzım var) — bugün nasılsın, ne anlatmak istersin?`;
}
