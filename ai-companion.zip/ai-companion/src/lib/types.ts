export interface Character {
  id: string;
  owner_id: string | null;
  name: string;
  age: number;
  gender: string;
  avatar: string;
  description: string;
  personality: string;
  background: string;
  speaking_style: string;
  interests: string[];
  dislikes: string[];
  relationship_type: string;
  greeting: string;
  system_prompt: string;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  character_id: string;
  role: "user" | "assistant";
  content: string;
  image_url?: string | null;
  created_at: string;
}

export interface Memory {
  id: string;
  user_id: string;
  character_id: string;
  memory: string;
  importance: number;
  created_at: string;
}

export interface RelationshipState {
  level: number; // 0-100
  tier: string;
}

export interface SessionUser {
  id: string;
  email: string;
  display_name: string;
}
