import { notFound } from "next/navigation";
import { getCharacterById } from "@/lib/characters/repo";
import { getSessionUser } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { getRelationship } from "@/lib/ai/relationship";
import ChatWindow from "@/components/ChatWindow";
import type { ChatMessage } from "@/lib/types";

export default function ChatPage({ params }: { params: { id: string } }) {
  const character = getCharacterById(params.id);
  if (!character) notFound();

  const user = getSessionUser();
  let history: ChatMessage[] = [];
  let relationship = { level: 5, tier: "Stranger" };

  if (user) {
    const db = getDb();
    history = db
      .prepare(
        `SELECT * FROM messages WHERE user_id = ? AND character_id = ? ORDER BY created_at ASC LIMIT 100`
      )
      .all(user.id, character.id) as ChatMessage[];
    relationship = getRelationship(user.id, character.id);
  }

  return (
    <ChatWindow
      character={character}
      initialHistory={history}
      initialRelationship={relationship}
      isLoggedIn={!!user}
    />
  );
}
