interface Props {
  role: "user" | "assistant";
  content: string;
  imageUrl?: string | null;
  timestamp?: string;
}

export default function MessageBubble({ role, content, imageUrl, timestamp }: Props) {
  const isUser = role === "user";
  return (
    <div className={`flex animate-fade-in ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed sm:max-w-[65%] ${
          isUser ? "bg-brand-gradient text-white" : "border border-border bg-surface text-text"
        }`}
      >
        {imageUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={imageUrl} alt="character" className="mb-2 w-full rounded-xl border border-border/60" />
        )}
        <p className="whitespace-pre-wrap">{content}</p>
        {timestamp && (
          <span className={`mt-1 block text-[10px] ${isUser ? "text-white/70" : "text-muted"}`}>
            {new Date(timestamp).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}
          </span>
        )}
      </div>
    </div>
  );
}
