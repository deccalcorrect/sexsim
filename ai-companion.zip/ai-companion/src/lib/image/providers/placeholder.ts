import type { ImageProvider } from "../provider";
import type { Character } from "../../types";

/**
 * Hiçbir API key gerektirmeyen varsayılan sağlayıcı. Gerçek bir
 * görsel üretmez; karakterin ismine göre renkli, stilize bir
 * "avatar" SVG'si üretir (data URL). Bu sayede sistem her zaman
 * çalışır durumda kalır; gerçek görsel üretimi istenirse
 * IMAGE_PROVIDER=huggingface ile değiştirilebilir.
 */
export class PlaceholderProvider implements ImageProvider {
  name = "placeholder";

  async generateImage(character: Character): Promise<string> {
    const initials = character.name
      .split(" ")
      .map((p) => p[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();

    const hue = hashToHue(character.name + Date.now());
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="hsl(${hue}, 80%, 55%)" />
            <stop offset="100%" stop-color="hsl(${(hue + 60) % 360}, 80%, 45%)" />
          </linearGradient>
        </defs>
        <rect width="512" height="512" fill="url(#g)" rx="32" />
        <text x="50%" y="52%" font-family="Arial, sans-serif" font-size="160"
          fill="white" text-anchor="middle" dominant-baseline="middle" opacity="0.9">
          ${initials}
        </text>
      </svg>`.trim();

    const base64 = Buffer.from(svg).toString("base64");
    return `data:image/svg+xml;base64,${base64}`;
  }
}

function hashToHue(input: string) {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    hash = (hash << 5) - hash + input.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 360;
}
