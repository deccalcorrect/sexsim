const TIER_COLORS: Record<string, string> = {
  Stranger: "bg-surface2 text-muted",
  Acquaintance: "bg-blue-500/20 text-blue-300",
  Friend: "bg-emerald-500/20 text-emerald-300",
  "Close Friend": "bg-primary/20 text-primary",
  "Best Friend": "bg-primary2/20 text-primary2",
};

export default function RelationshipBadge({ tier, level }: { tier: string; level: number }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${TIER_COLORS[tier] || TIER_COLORS.Stranger}`}>
        {tier}
      </span>
      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-surface2">
        <div className="h-full bg-brand-gradient transition-all" style={{ width: `${level}%` }} />
      </div>
    </div>
  );
}
