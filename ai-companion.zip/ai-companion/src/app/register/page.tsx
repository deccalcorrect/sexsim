"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, displayName }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error || "Kayıt başarısız.");
      return;
    }
    router.push("/");
    router.refresh();
  }

  return (
    <div className="mx-auto mt-10 max-w-sm rounded-xl2 border border-border bg-surface p-6">
      <h1 className="mb-6 text-center text-2xl font-semibold">Kayıt Ol</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input
          type="text"
          placeholder="Görünen isim"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          className="rounded-lg border border-border bg-surface2 px-4 py-2.5 outline-none focus:border-primary"
        />
        <input
          type="email"
          required
          placeholder="E-posta"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="rounded-lg border border-border bg-surface2 px-4 py-2.5 outline-none focus:border-primary"
        />
        <input
          type="password"
          required
          placeholder="Şifre (en az 6 karakter)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="rounded-lg border border-border bg-surface2 px-4 py-2.5 outline-none focus:border-primary"
        />
        {error && <p className="text-sm text-primary2">{error}</p>}
        <button
          disabled={loading}
          className="rounded-full bg-brand-gradient py-2.5 font-medium text-white transition hover:opacity-90 disabled:opacity-50"
        >
          {loading ? "Kayıt oluyor..." : "Kayıt Ol"}
        </button>
      </form>
      <p className="mt-4 text-center text-sm text-muted">
        Zaten hesabın var mı?{" "}
        <Link href="/login" className="text-primary">
          Giriş yap
        </Link>
      </p>
    </div>
  );
}
