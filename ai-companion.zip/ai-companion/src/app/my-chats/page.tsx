import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { tierForLevel } from "@/lib/ai/relationship";

export default function MyChatsPage() {
  const user = getSessionUser();

  if (!user) {
    return (
      <div className="mx-auto mt-16 max-w-md text-center">
        <p className="text-muted">
          Sohbetlerini görmek için{" "}
          <Link href="/login" className="text-primary">
            giriş yap
          </Link>
          .
        </p>
      </div>
    );
  }

  const db = getDb();
  const chats = db
    .prepare(
      `SELECT c.id, c.name, r.level,
              (SELECT content FROM messages m WHERE m.user_id = ? AND m.character_id = c.id
                ORDER BY m.created_at DESC LIMIT 1) as last_message,
              (SELECT MAX(created_at) FROM messages m WHERE m.user_id = ? AND m.character_id = c.id) as last_at
       FROM characters c
       JOIN relationships r ON r.character_id = c.id AND r.user_id = ?
       WHERE EXISTS (SELECT 1 FROM messages m2 WHERE m2.user_id = ? AND m2.character_id = c.id)
       ORDER BY last_at DESC`
    )
    .all(user.id, user.id, user.id, user.id) as any[];

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="mb-6 text-2xl font-semibold">My Chats</h1>
      {chats.length === 0 ? (
        <p className="text-center text-muted">
          Henüz bir sohbetin yok.{" "}
          <Link href="/" className="text-primary">
            Karakterleri keşfet
          </Link>
          .
        </p>
      ) : (
        <div className="space-y-2">
          {chats.map((c) => (
            <Link
              key={c.id}
              href={`/chat/${c.id}`}
              className="card-hover flex items-center justify-between rounded-xl2 border border-border bg-surface p-4"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-gradient font-bold text-white">
                  {c.name[0]}
                </div>
                <div>
                  <p className="font-medium">{c.name}</p>
                  <p className="line-clamp-1 text-sm text-muted">{c.last_message}</p>
                </div>
              </div>
              <span className="rounded-full bg-surface2 px-2.5 py-0.5 text-xs text-muted">
                {tierForLevel(c.level)}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
