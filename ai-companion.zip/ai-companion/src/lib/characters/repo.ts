import { v4 as uuid } from "uuid";
import { getDb } from "../db";
import type { Character } from "../types";
import { buildSystemPrompt, defaultGreeting } from "../ai/systemPrompt";
import { SEED_CHARACTERS, buildSeedCharacterRow } from "./seed";

function rowToCharacter(row: any): Character {
  return {
    ...row,
    interests: JSON.parse(row.interests || "[]"),
    dislikes: JSON.parse(row.dislikes || "[]"),
  };
}

/** Uygulama ilk kez çalıştığında örnek karakterleri otomatik ekler. */
export function ensureSeeded() {
  const db = getDb();
  const count = db.prepare("SELECT COUNT(*) as c FROM characters").get() as { c: number };
  if (count.c > 0) return;

  const insert = db.prepare(`
    INSERT INTO characters
    (id, owner_id, name, age, gender, avatar, description, personality, background,
     speaking_style, interests, dislikes, relationship_type, greeting, system_prompt, created_at)
    VALUES (@id, @owner_id, @name, @age, @gender, @avatar, @description, @personality, @background,
     @speaking_style, @interests, @dislikes, @relationship_type, @greeting, @system_prompt, @created_at)
  `);

  for (const seed of SEED_CHARACTERS) {
    const row = buildSeedCharacterRow(seed);
    insert.run({
      ...row,
      interests: JSON.stringify(row.interests),
      dislikes: JSON.stringify(row.dislikes),
    });
  }
}

export function getAllCharacters(): Character[] {
  ensureSeeded();
  const db = getDb();
  const rows = db.prepare("SELECT * FROM characters ORDER BY created_at DESC").all();
  return rows.map(rowToCharacter);
}

export function getCharacterById(id: string): Character | null {
  ensureSeeded();
  const db = getDb();
  const row = db.prepare("SELECT * FROM characters WHERE id = ?").get(id);
  return row ? rowToCharacter(row) : null;
}

export interface CreateCharacterInput {
  ownerId: string;
  name: string;
  age: number;
  gender: string;
  description: string;
  personality: string;
  background: string;
  speaking_style: string;
  interests: string[];
  dislikes: string[];
  relationship_type: string;
  greeting?: string;
  avatar?: string;
}

export function createCharacter(input: CreateCharacterInput): Character {
  const db = getDb();
  const id = uuid();
  const systemPrompt = buildSystemPrompt({
    name: input.name,
    age: input.age,
    gender: input.gender,
    avatar: input.avatar || "",
    description: input.description,
    personality: input.personality,
    background: input.background,
    speaking_style: input.speaking_style,
    interests: input.interests,
    dislikes: input.dislikes,
    relationship_type: input.relationship_type,
    greeting: "",
  });
  const greeting = input.greeting?.trim() || defaultGreeting(input.name, input.speaking_style);
  const created_at = new Date().toISOString();

  db.prepare(`
    INSERT INTO characters
    (id, owner_id, name, age, gender, avatar, description, personality, background,
     speaking_style, interests, dislikes, relationship_type, greeting, system_prompt, created_at)
    VALUES (@id, @owner_id, @name, @age, @gender, @avatar, @description, @personality, @background,
     @speaking_style, @interests, @dislikes, @relationship_type, @greeting, @system_prompt, @created_at)
  `).run({
    id,
    owner_id: input.ownerId,
    name: input.name,
    age: input.age,
    gender: input.gender,
    avatar: input.avatar || "",
    description: input.description,
    personality: input.personality,
    background: input.background,
    speaking_style: input.speaking_style,
    interests: JSON.stringify(input.interests),
    dislikes: JSON.stringify(input.dislikes),
    relationship_type: input.relationship_type,
    greeting,
    system_prompt: systemPrompt,
    created_at,
  });

  return getCharacterById(id)!;
}
