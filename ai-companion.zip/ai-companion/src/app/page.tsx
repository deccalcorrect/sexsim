import { getAllCharacters } from "@/lib/characters/repo";
import CharacterCard from "@/components/CharacterCard";
import Link from "next/link";

export default function HomePage() {
  const characters = getAllCharacters();

  return (
    <div>
      <section className="flex flex-col items-center gap-4 py-14 text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
          Meet your <span className="brand-text">AI companion.</span>
        </h1>
        <p className="max-w-xl text-muted">
          Create characters, start conversations and build relationships that evolve over time.
        </p>
        <Link
          href="/create-character"
          className="mt-2 rounded-full bg-brand-gradient px-6 py-2.5 text-sm font-medium text-white shadow-lg shadow-primary/20 transition hover:opacity-90"
        >
          Karakterini Oluştur
        </Link>
      </section>

      <section className="mt-4">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Discover</h2>
          <span className="text-sm text-muted">{characters.length} karakter</span>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {characters.map((c) => (
            <CharacterCard key={c.id} character={c} />
          ))}
        </div>
      </section>
    </div>
  );
}
