import { v4 as uuid } from "uuid";
import { getDb } from "../db";
import type { Memory } from "../types";

/**
 * Basit, kural tabanlı hafıza çıkarımı. Her kullanıcı mesajı LLM'e
 * göndermek yerine, mesajı tarayıp "önemli" görünen bilgileri
 * (yaşadığı yer, sevdiği/sevmediği şeyler, mesleği, isim vb.)
 * memories tablosuna kaydeder. Bu, hem prompt'u kısa tutar hem de
 * ücretli bir çıkarım modeline ihtiyaç duymaz.
 *
 * Not: Gerçek bir LLM sağlayıcısı kullanılıyorsa (openrouter/claude),
 * istenirse bu fonksiyon LLM'e "bu mesajdan önemli bir bilgi çıkar"
 * diye sorarak da genişletilebilir — arayüz aynı kalır.
 */
const PATTERNS: { regex: RegExp; importance: number }[] = [
  { regex: /ben(im)?\s+([a-zçğıöşü]+)('de|'da|de|da)\s+yaşıyorum/i, importance: 3 },
  { regex: /adım\s+([a-zçğıöşü]+)/i, importance: 3 },
  { regex: /benim\s+ad[ıi]m\s+([a-zçğıöşü]+)/i, importance: 3 },
  { regex: /(\d{1,2})\s*yaşındayım/i, importance: 2 },
  { regex: /([a-zçğıöşü\s]+)\s+seviyorum/i, importance: 2 },
  { regex: /([a-zçğıöşü\s]+)\s+sevmiyorum|nefret ediyorum/i, importance: 2 },
  { regex: /mesleğim\s+([a-zçğıöşü\s]+)/i, importance: 2 },
  { regex: /([a-zçğıöşü\s]+)\s+ile\s+çalışıyorum/i, importance: 1 },
  { regex: /doğum\s*günüm\s+([a-zçğıöşü0-9\s]+)/i, importance: 3 },
];

export function extractAndStoreMemories(userId: string, characterId: string, message: string) {
  const db = getDb();
  const found: string[] = [];

  for (const { regex } of PATTERNS) {
    if (regex.test(message)) {
      found.push(message.trim());
      break; // bir mesajdan bir hafıza kaydı yeterli, tekrar tekrar eklemeyelim
    }
  }

  if (found.length === 0) return;

  const insert = db.prepare(
    `INSERT INTO memories (id, user_id, character_id, memory, importance, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  );
  for (const memory of found) {
    insert.run(uuid(), userId, characterId, memory, 2, new Date().toISOString());
  }
}

/**
 * Yeni mesaja en alakalı hafızaları getirir (basit kelime örtüşmesi
 * ile skorlanır). Tüm geçmişi her seferinde prompt'a göndermek yerine
 * en fazla `limit` kadar en alakalı/önemli hafıza döner.
 */
export function retrieveRelevantMemories(
  userId: string,
  characterId: string,
  currentMessage: string,
  limit = 5
): string[] {
  const db = getDb();
  const all = db
    .prepare(
      `SELECT * FROM memories WHERE user_id = ? AND character_id = ? ORDER BY created_at DESC LIMIT 200`
    )
    .all(userId, characterId) as Memory[];

  if (all.length === 0) return [];

  const words = new Set(
    currentMessage
      .toLowerCase()
      .split(/\W+/)
      .filter((w) => w.length > 3)
  );

  const scored = all.map((m) => {
    const memWords = m.memory.toLowerCase().split(/\W+/);
    const overlap = memWords.filter((w) => words.has(w)).length;
    return { memory: m, score: overlap * 2 + m.importance };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit).map((s) => s.memory.memory);
}
