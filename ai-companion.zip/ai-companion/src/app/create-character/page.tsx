import { getSessionUser } from "@/lib/auth";
import CharacterForm from "@/components/CharacterForm";
import Link from "next/link";

export default function CreateCharacterPage() {
  const user = getSessionUser();

  if (!user) {
    return (
      <div className="mx-auto mt-16 max-w-md text-center">
        <p className="text-muted">
          Karakter oluşturmak için önce{" "}
          <Link href="/login" className="text-primary">
            giriş yapmalısın
          </Link>
          .
        </p>
      </div>
    );
  }

  return (
    <div>
      <h1 className="mb-6 text-center text-2xl font-semibold">Create Your Character</h1>
      <CharacterForm />
    </div>
  );
}
