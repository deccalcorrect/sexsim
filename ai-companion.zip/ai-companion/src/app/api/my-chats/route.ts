import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { getDb } from "@/lib/db";
import { tierForLevel } from "@/lib/ai/relationship";

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ chats: [] });

  const db = getDb();
  const rows = db
    .prepare(
      `SELECT c.id, c.name, c.avatar, r.level,
              (SELECT content FROM messages m WHERE m.user_id = ? AND m.character_id = c.id
                ORDER BY m.created_at DESC LIMIT 1) as last_message,
              (SELECT MAX(created_at) FROM messages m WHERE m.user_id = ? AND m.character_id = c.id) as last_at
       FROM characters c
       JOIN relationships r ON r.character_id = c.id AND r.user_id = ?
       WHERE EXISTS (SELECT 1 FROM messages m2 WHERE m2.user_id = ? AND m2.character_id = c.id)
       ORDER BY last_at DESC`
    )
    .all(user.id, user.id, user.id, user.id) as any[];

  const chats = rows.map((r) => ({
    characterId: r.id,
    name: r.name,
    avatar: r.avatar,
    lastMessage: r.last_message,
    lastAt: r.last_at,
    relationship: { level: r.level, tier: tierForLevel(r.level) },
  }));

  return NextResponse.json({ chats });
}
