import { NextResponse } from "next/server";
import { getCharacterById } from "@/lib/characters/repo";
import { getDb } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { getRelationship } from "@/lib/ai/relationship";
import type { ChatMessage } from "@/lib/types";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const character = getCharacterById(params.id);
  if (!character) {
    return NextResponse.json({ error: "Karakter bulunamadı." }, { status: 404 });
  }

  const user = getSessionUser();
  let history: ChatMessage[] = [];
  let relationship = { level: 5, tier: "Stranger" };

  if (user) {
    const db = getDb();
    history = db
      .prepare(
        `SELECT * FROM messages WHERE user_id = ? AND character_id = ? ORDER BY created_at ASC LIMIT 100`
      )
      .all(user.id, character.id) as ChatMessage[];
    relationship = getRelationship(user.id, character.id);
  }

  return NextResponse.json({ character, history, relationship });
}
